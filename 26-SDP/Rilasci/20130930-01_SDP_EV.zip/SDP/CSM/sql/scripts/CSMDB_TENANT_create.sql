CREATE DATABASE CSMDB_TENANTX;

ALTER SCHEMA CSMDB_TENANTX DEFAULT CHARACTER

SET latin7 DEFAULT COLLATE latin7_general_cs;

USE CSMDB_TENANTX;

/*--------------------------------------------------------
--  DDL for Table REF_CSM_CONSTANTS
--------------------------------------------------------*/

CREATE TABLE `REF_CSM_CONSTANTS` (
	`CONSTANT_KEY` VARCHAR(50) NOT NULL COMMENT 'Unique constant name', 
	`CONSTANT_VALUE` VARCHAR(50) NOT NULL COMMENT 'Constant value'
	) ENGINE=INNODB COMMENT 'Ref table for constant values for this particular tenant';

ALTER TABLE `REF_CSM_CONSTANTS` ADD PRIMARY KEY (`CONSTANT_KEY`);

/*--------------------------------------------------------
--  DDL for Table REF_ENTITY_TYPE
--------------------------------------------------------*/
CREATE TABLE `REF_ENTITY_TYPE` (
	`ENTITY_ID` BIGINT NOT NULL COMMENT 'Entity identifier',
	`ENTITY_NAME` VARCHAR(100) NOT NULL COMMENT 'Entity name',
	`ENTITY_DESCRIPTION` VARCHAR(255) COMMENT 'Entity description',
	`CREATED_BY_ID` VARCHAR(100) COMMENT 'ID of creator',
	`CREATED_DATE` DATETIME COMMENT 'Datetime of creation',
	`UPDATED_BY_ID` VARCHAR(100) COMMENT 'ID of last modifier',
	`UPDATED_DATE` DATETIME COMMENT 'Datetime of last modification'
	) ENGINE = INNODB COMMENT 'Ref table for entity typology (used on SDP_STATUS_VARIATION)';

ALTER TABLE `REF_ENTITY_TYPE` ADD UNIQUE INDEX `UK-REF_ENTITY_TYPE-ENTITY_NAME` (`ENTITY_NAME`);

ALTER TABLE `REF_ENTITY_TYPE` ADD PRIMARY KEY (`ENTITY_ID`);

/*--------------------------------------------------------
--  DDL for Table SDP_STATUS_VARIATION
--------------------------------------------------------*/
CREATE TABLE `SDP_STATUS_VARIATION` (
	`ENTITY_ID` BIGINT NOT NULL COMMENT 'Entity identifier (ref on REF_ENTITY_TYPE)',
	`PREVIOUS_STATUS_ID` BIGINT NOT NULL COMMENT 'Previous (OLD) Status ID',
	`NEXT_STATUS_ID` BIGINT NOT NULL COMMENT 'Next (NEW) Status ID',
	`CREATED_BY_ID` VARCHAR(100) COMMENT 'ID of creator',
	`CREATED_DATE` DATETIME COMMENT 'Datetime of creation',
	`UPDATED_BY_ID` VARCHAR(100) COMMENT 'ID of last modifier',
	`UPDATED_DATE` DATETIME COMMENT 'Datetime of last modification'
	) ENGINE = INNODB COMMENT 'Table for mapping of permitted status variation';

ALTER TABLE `SDP_STATUS_VARIATION` ADD PRIMARY KEY (
	`ENTITY_ID`,
	`PREVIOUS_STATUS_ID`,
	`NEXT_STATUS_ID`
	);

/*--------------------------------------------------------
--  DDL for Table REF_SERVICE_TYPE
--------------------------------------------------------*/
CREATE TABLE `REF_SERVICE_TYPE` (
	`SERVICE_TYPE_ID` BIGINT NOT NULL COMMENT 'Service typology identifier',
	`SERVICE_TYPE_NAME` VARCHAR(100) NOT NULL COMMENT 'Service typology name',
	`SERVICE_TYPE_DESCRIPTION` VARCHAR(255) COMMENT 'Service typology description',
	`CREATED_BY_ID` VARCHAR(100) COMMENT 'ID of creator',
	`CREATED_DATE` DATETIME COMMENT 'Datetime of creation',
	`UPDATED_BY_ID` VARCHAR(100) COMMENT 'ID of last modifier',
	`UPDATED_DATE` DATETIME COMMENT 'Datetime of last modification'
	) ENGINE = INNODB COMMENT 'Ref table for service typologies';

ALTER TABLE `REF_SERVICE_TYPE` ADD UNIQUE INDEX `UK-REF_SERVICE_TYPE-SRVTPNAME` (`SERVICE_TYPE_NAME`);

ALTER TABLE `REF_SERVICE_TYPE` ADD PRIMARY KEY (`SERVICE_TYPE_ID`);

/*--------------------------------------------------------
--  DDL for Table SDP_PLATFORM
--------------------------------------------------------*/
CREATE TABLE `SDP_PLATFORM` (
	`PLATFORM_ID` BIGINT NOT NULL AUTO_INCREMENT COMMENT 'Platform identifier',
	`PLATFORM_NAME` VARCHAR(100) NOT NULL COMMENT 'Platform name',
	`PLATFORM_DESCRIPTION` VARCHAR(255) COMMENT 'Platform description',
	`STATUS_ID` BIGINT DEFAULT 2 NOT NULL COMMENT 'Status identifier',
	`PLATFORM_PROFILE` TEXT (64000) COMMENT 'XML for platform profiling',
	`EXTERNAL_ID` VARCHAR(50) COMMENT 'Identifier for external system',
	`CREATED_BY_ID` VARCHAR(100) COMMENT 'ID of creator',
	`CREATED_DATE` DATETIME COMMENT 'Datetime of creation',
	`UPDATED_BY_ID` VARCHAR(100) COMMENT 'ID of last modifier',
	`UPDATED_DATE` DATETIME COMMENT 'Datetime of last modification',
	`DELETED_BY_ID` VARCHAR(100) COMMENT 'ID of eraser (logical deletion)',
	`DELETED_DATE` DATETIME COMMENT 'Datetime of logical deletion',
	`CHG_STATUS_BY_ID` VARCHAR(100) COMMENT 'ID of last STATUS modifier',
	`CHG_STATUS_DATE` DATETIME COMMENT 'Datetime of last STATUS modification',
	PRIMARY KEY (`PLATFORM_ID`)
	) ENGINE = INNODB COMMENT 'Table for platform description';

ALTER TABLE `SDP_PLATFORM` ADD UNIQUE INDEX `UK-SDP_PLATFORM-PLATFORM_NAME` (`PLATFORM_NAME`);

ALTER TABLE `SDP_PLATFORM` ADD UNIQUE INDEX `UK-SDP_PLATFORM-EXTERNAL_ID` (`EXTERNAL_ID`);

/*--------------------------------------------------------
--  DDL for Table SDP_SERVICE_TEMPLATE
--------------------------------------------------------*/
CREATE TABLE `SDP_SERVICE_TEMPLATE` (
	`SERVICE_TEMPLATE_ID` BIGINT NOT NULL AUTO_INCREMENT COMMENT 'Service template identifier',
	`SERVICE_TEMPLATE_NAME` VARCHAR(100) NOT NULL COMMENT 'Service template name',
	`SERVICE_TEMPLATE_DESCRIPTION` VARCHAR(255) COMMENT 'XML for service template profiling',
	`STATUS_ID` BIGINT DEFAULT 2 NOT NULL COMMENT 'Status identifier',
	`PLATFORM_ID` BIGINT NOT NULL COMMENT 'Platform identifier',
	`SERVICE_TYPE_ID` BIGINT NOT NULL COMMENT 'Service typology identifier',
	`SERVICE_TEMPLATE_PROFILE` TEXT (64000) COMMENT 'Service template description',
	`EXTERNAL_ID` VARCHAR(50) COMMENT 'Identifier for external system',
	`CREATED_BY_ID` VARCHAR(100) COMMENT 'ID of creator',
	`CREATED_DATE` DATETIME COMMENT 'Datetime of creation',
	`UPDATED_BY_ID` VARCHAR(100) COMMENT 'ID of last modifier',
	`UPDATED_DATE` DATETIME COMMENT 'Datetime of last modification',
	`DELETED_BY_ID` VARCHAR(100) COMMENT 'ID of eraser (logical deletion)',
	`DELETED_DATE` DATETIME COMMENT 'Datetime of logical deletion',
	`CHG_STATUS_BY_ID` VARCHAR(100) COMMENT 'ID of last STATUS modifier',
	`CHG_STATUS_DATE` DATETIME COMMENT 'Datetime of last STATUS modification',
	PRIMARY KEY (`SERVICE_TEMPLATE_ID`)
	) ENGINE = INNODB COMMENT 'Table for service template definition';

ALTER TABLE `SDP_SERVICE_TEMPLATE` ADD UNIQUE INDEX `UK-SDP_SRVTEMPLATE-SRVTMPLNAME` (`SERVICE_TEMPLATE_NAME`);

ALTER TABLE `SDP_SERVICE_TEMPLATE` ADD INDEX `IDX_SERVICE_TEMPLATE_PLATFORM` (`PLATFORM_ID`);

ALTER TABLE `SDP_SERVICE_TEMPLATE` ADD INDEX `IDX_SERVICE_TEMPLATE_TYPE_ID` (`SERVICE_TYPE_ID`);

ALTER TABLE `SDP_SERVICE_TEMPLATE` ADD UNIQUE INDEX `UK-SDP_SRVTEMPLATE-EXTERNAL_ID` (`EXTERNAL_ID`);

ALTER TABLE `SDP_SERVICE_TEMPLATE` ADD CONSTRAINT `FK-SDP_SRVTEMPLATE-SRVTYPEID` FOREIGN KEY (`SERVICE_TYPE_ID`) REFERENCES `REF_SERVICE_TYPE` (`SERVICE_TYPE_ID`);

ALTER TABLE `SDP_SERVICE_TEMPLATE` ADD CONSTRAINT `FK-SDP_SRVTEMPLATE-PLATFORMID` FOREIGN KEY (`PLATFORM_ID`) REFERENCES `SDP_PLATFORM` (`PLATFORM_ID`);

/*--------------------------------------------------------
--  DDL for Table SDP_SERVICE_VARIANT
--------------------------------------------------------*/
CREATE TABLE `SDP_SERVICE_VARIANT` (
	`SERVICE_VARIANT_ID` BIGINT NOT NULL AUTO_INCREMENT COMMENT 'Service variant identifier',
	`SERVICE_VARIANT_NAME` VARCHAR(100) NOT NULL COMMENT 'Service variant name',
	`SERVICE_VARIANT_DESCRIPTION` VARCHAR(255) COMMENT 'Service variant description',
	`SERVICE_TEMPLATE_ID` BIGINT COMMENT 'Service template identifier',
	`STATUS_ID` BIGINT DEFAULT 2 NOT NULL COMMENT 'Status identifier',
	`EXTERNAL_ID` VARCHAR(50) COMMENT 'Identifier for external system',
	`SERVICE_VARIANT_PROFILE` TEXT (64000) COMMENT 'XML for service variant profiling',
	`CREATED_BY_ID` VARCHAR(100) COMMENT 'ID of creator',
	`CREATED_DATE` DATETIME COMMENT 'Datetime of creation',
	`UPDATED_BY_ID` VARCHAR(100) COMMENT 'ID of last modifier',
	`UPDATED_DATE` DATETIME COMMENT 'Datetime of last modification',
	`DELETED_BY_ID` VARCHAR(100) COMMENT 'ID of eraser (logical deletion)',
	`DELETED_DATE` DATETIME COMMENT 'Datetime of logical deletion',
	`CHG_STATUS_BY_ID` VARCHAR(100) COMMENT 'ID of last STATUS modifier',
	`CHG_STATUS_DATE` DATETIME COMMENT 'Datetime of last STATUS modification',
	CONSTRAINT `PK-SDP_SRVVARIANT` PRIMARY KEY (`SERVICE_VARIANT_ID`)
	) ENGINE = INNODB COMMENT 'Table for service variant definition';

ALTER TABLE `SDP_SERVICE_VARIANT` ADD UNIQUE INDEX `UK-SDP_SRVVARIANT-SRVVARNTNAME` (`SERVICE_VARIANT_NAME`);

ALTER TABLE `SDP_SERVICE_VARIANT` ADD INDEX `IDX_SERVICE_VARIANT_TEMPL_ID` (`SERVICE_TEMPLATE_ID`);

ALTER TABLE `SDP_SERVICE_VARIANT` ADD UNIQUE INDEX `UK-SDP_SRVVARIANT-EXTERNAL_ID` (`EXTERNAL_ID`);

ALTER TABLE `SDP_SERVICE_VARIANT` ADD CONSTRAINT `FK-SDP_SRVVARIANT-SRVTMPLATEID` FOREIGN KEY (`SERVICE_TEMPLATE_ID`) REFERENCES `SDP_SERVICE_TEMPLATE` (`SERVICE_TEMPLATE_ID`);

/*--------------------------------------------------------
--  DDL for Table SDP_SERVICE_VARIANT_OPERATION
--------------------------------------------------------*/
CREATE TABLE `SDP_SERVICE_VARIANT_OPERATION` (
	`SERVICE_VARIANT_ID` BIGINT NOT NULL COMMENT 'Service variant identifier',
	`METHOD_NAME` VARCHAR(100) NOT NULL COMMENT 'Method name to be invoked',
	`OPERATION_TYPE` VARCHAR(100) COMMENT 'Operation type to be invoked',
	`INPUT_XSLT` TEXT (64000) COMMENT 'XSLT for trasformation input',
	`OUTPUT_XSLT` TEXT (64000) COMMENT 'XSLT for trasformation output',
	`INPUT_PARAMETERS` TEXT (64000) COMMENT 'Input parameters for the method',
	`UDDI_KEY` VARCHAR(500) COMMENT 'Uddi key',
	`CREATED_BY_ID` VARCHAR(100) COMMENT 'ID of creator',
	`CREATED_DATE` DATETIME COMMENT 'Datetime of creation',
	`UPDATED_BY_ID` VARCHAR(100) COMMENT 'ID of last modifier',
	`UPDATED_DATE` DATETIME COMMENT 'Datetime of last modification'
	) ENGINE = INNODB COMMENT 'Table for SO service variant configuration';

ALTER TABLE `SDP_SERVICE_VARIANT_OPERATION` ADD CONSTRAINT `PK-SERVICE_VARIANT_OPERATION` PRIMARY KEY (
	`SERVICE_VARIANT_ID`,
	`METHOD_NAME`
	);

ALTER TABLE `SDP_SERVICE_VARIANT_OPERATION` ADD INDEX `IDX_SRVVRNOPERAT_METHOD_NAME` (`METHOD_NAME`);

ALTER TABLE `SDP_SERVICE_VARIANT_OPERATION` ADD CONSTRAINT `FK-SRVVRNOPERAT-SRVVRNID` FOREIGN KEY (`SERVICE_VARIANT_ID`) REFERENCES `SDP_SERVICE_VARIANT` (`SERVICE_VARIANT_ID`);

/*--------------------------------------------------------
--  DDL for Table REF_FREQUENCY_TYPE
--------------------------------------------------------*/
CREATE TABLE `REF_FREQUENCY_TYPE` (
	`FREQUENCY_TYPE_ID` BIGINT NOT NULL AUTO_INCREMENT COMMENT 'Frequency typology identifier',
	`FREQUENCY_TYPE_NAME` VARCHAR(100) NOT NULL COMMENT 'Frequency typology name',
	`FREQUENCY_TYPE_DESCRIPTION` VARCHAR(255) COMMENT 'Frequency typology description',
	`FREQUENCY_IN_DAYS` BIGINT NOT NULL COMMENT 'Frequency value in days',
	`CREATED_BY_ID` VARCHAR(100) COMMENT 'ID of creator',
	`CREATED_DATE` DATETIME COMMENT 'Datetime of creation',
	`UPDATED_BY_ID` VARCHAR(100) COMMENT 'ID of last modifier',
	`UPDATED_DATE` DATETIME COMMENT 'Datetime of last modification',
	PRIMARY KEY (`FREQUENCY_TYPE_ID`)
	) ENGINE = INNODB COMMENT 'Ref table for frequency type values (for recurring charge)';

ALTER TABLE `REF_FREQUENCY_TYPE` ADD UNIQUE INDEX `UK-REF_FREQUENCY_TYPE-FREQNAME` (`FREQUENCY_TYPE_NAME`);

/*--------------------------------------------------------
--  DDL for Table REF_PRICE_CATALOG
--------------------------------------------------------*/
CREATE TABLE `REF_PRICE_CATALOG` (
	`PRICE_CATALOG_ID` BIGINT NOT NULL AUTO_INCREMENT COMMENT 'Price catalog identifier',
	`PRICE` DECIMAL(10, 2) NOT NULL COMMENT 'Price value',
	`CREATED_BY_ID` VARCHAR(100) COMMENT 'ID of creator',
	`CREATED_DATE` DATETIME COMMENT 'Datetime of creation',
	`UPDATED_BY_ID` VARCHAR(100) COMMENT 'ID of last modifier',
	`UPDATED_DATE` DATETIME COMMENT 'Datetime of last modification',
	PRIMARY KEY (`PRICE_CATALOG_ID`)
	) ENGINE = INNODB COMMENT 'Ref table for price values (for RC and NRC)';

ALTER TABLE `REF_PRICE_CATALOG` ADD UNIQUE INDEX `UK-REF_PRICE_CATALOG-PRICE` (`PRICE`);

/*--------------------------------------------------------
--  DDL for Table REF_CURRENCY_TYPE
--------------------------------------------------------*/
CREATE TABLE `REF_CURRENCY_TYPE` (
	`CURRENCY_TYPE_ID` BIGINT NOT NULL AUTO_INCREMENT COMMENT 'Currency typology identifier',
	`CURRENCY_TYPE_NAME` VARCHAR(50) NOT NULL COMMENT 'Currency typology name',
	`CREATED_BY_ID` VARCHAR(100) COMMENT 'ID of creator',
	`CREATED_DATE` DATETIME COMMENT 'Datetime of creation',
	`UPDATED_BY_ID` VARCHAR(100) COMMENT 'ID of last modifier',
	`UPDATED_DATE` DATETIME COMMENT 'Datetime of last modification',
	PRIMARY KEY (`CURRENCY_TYPE_ID`)
	) ENGINE = INNODB COMMENT 'Ref table for currency values';

ALTER TABLE `REF_CURRENCY_TYPE` ADD UNIQUE INDEX `UK-REF_CURRENCY_TYPE-CURRNAME` (`CURRENCY_TYPE_NAME`);

/*--------------------------------------------------------
--  DDL for Table SDP_PACKAGE_PRICE
--------------------------------------------------------*/
CREATE TABLE `SDP_PACKAGE_PRICE` (
	`PACKAGE_PRICE_ID` BIGINT NOT NULL AUTO_INCREMENT COMMENT 'Package price identifier',
	`RC_FREQUENCY_TYPE_ID` BIGINT NOT NULL COMMENT 'Frequency typology for recurring charge',
	`RC_PRICE_CATALOG_ID` BIGINT NOT NULL COMMENT 'Price catalog for recurring charge',
	`RC_FLAG_PRORATE` CHAR(1) NOT NULL COMMENT 'Flag for prorate recurring charge (Y-N)' CHECK (
		`RC_FLAG_PRORATE` IN (
			'Y',
			'N'
			)
		),
	`RC_IN_ADVANCE` CHAR(1) NOT NULL COMMENT 'Flag for recurring charge payable in advance (Y-N)' CHECK (
		`RC_IN_ADVANCE` IN (
			'Y',
			'N'
			)
		),
	`NRC_PRICE_CATALOG_ID` BIGINT NOT NULL COMMENT 'Price catalog for not-recurring charge',
	`CURRENCY_TYPE_ID` BIGINT NOT NULL COMMENT 'Currency identifier',
	`CREATED_BY_ID` VARCHAR(100) COMMENT 'ID of creator',
	`CREATED_DATE` DATETIME COMMENT 'Datetime of creation',
	`UPDATED_BY_ID` VARCHAR(100) COMMENT 'ID of last modifier',
	`UPDATED_DATE` DATETIME COMMENT 'Datetime of last modification',
	PRIMARY KEY (`PACKAGE_PRICE_ID`)
	) ENGINE = INNODB COMMENT 'Table for package price catalog (ref by SDP_PACKAGE)';

ALTER TABLE `SDP_PACKAGE_PRICE` ADD CONSTRAINT `FK-SDP_PACKAGE_PRICE-RCFREQTP` FOREIGN KEY (`RC_FREQUENCY_TYPE_ID`) REFERENCES `REF_FREQUENCY_TYPE` (`FREQUENCY_TYPE_ID`);

ALTER TABLE `SDP_PACKAGE_PRICE` ADD CONSTRAINT `FK-SDP_PACKAGE_PRICE-RCPRICE` FOREIGN KEY (`RC_PRICE_CATALOG_ID`) REFERENCES `REF_PRICE_CATALOG` (`PRICE_CATALOG_ID`);

ALTER TABLE `SDP_PACKAGE_PRICE` ADD CONSTRAINT `FK-SDP_PACKAGE_PRICE-NRCPRICE` FOREIGN KEY (`NRC_PRICE_CATALOG_ID`) REFERENCES `REF_PRICE_CATALOG` (`PRICE_CATALOG_ID`);

ALTER TABLE `SDP_PACKAGE_PRICE` ADD CONSTRAINT `FK-SDP_PACKAGE_PRICE-CURRTPID` FOREIGN KEY (`CURRENCY_TYPE_ID`) REFERENCES `REF_CURRENCY_TYPE` (`CURRENCY_TYPE_ID`);

/*--------------------------------------------------------
--  DDL for Table REF_SOLUTION_TYPE
--------------------------------------------------------*/
CREATE TABLE `REF_SOLUTION_TYPE` (
	`SOLUTION_TYPE_ID` BIGINT NOT NULL COMMENT 'Solution typology identifier',
	`SOLUTION_TYPE_NAME` VARCHAR(100) NOT NULL COMMENT 'Solution typology name',
	`SOLUTION_TYPE_DESCRIPTION` VARCHAR(255) COMMENT 'Solution typology description',
	`CREATED_BY_ID` VARCHAR(100) COMMENT 'ID of creator',
	`CREATED_DATE` DATETIME COMMENT 'Datetime of creation',
	`UPDATED_BY_ID` VARCHAR(100) COMMENT 'ID of last modifier',
	`UPDATED_DATE` DATETIME COMMENT 'Datetime of last modification'
	) ENGINE = INNODB COMMENT 'Ref table for solution typologies';

ALTER TABLE `REF_SOLUTION_TYPE` ADD UNIQUE INDEX `UK-REF_SOLUTION_TYPE-SOLTPNAME` (`SOLUTION_TYPE_NAME`);

ALTER TABLE `REF_SOLUTION_TYPE` ADD PRIMARY KEY (`SOLUTION_TYPE_ID`);

/*--------------------------------------------------------
--  DDL for Table SDP_OFFER
--------------------------------------------------------*/
CREATE TABLE `SDP_OFFER` (
	`OFFER_ID` BIGINT NOT NULL AUTO_INCREMENT COMMENT 'Offer identifier',
	`OFFER_NAME` VARCHAR(100) NOT NULL COMMENT 'Offer name',
	`OFFER_DESCRIPTION` VARCHAR(255) COMMENT 'Offer description',
	`STATUS_ID` BIGINT DEFAULT 2 NOT NULL COMMENT 'Status identifier',
	`SERVICE_VARIANT_ID` BIGINT COMMENT 'Service variant identifier',
	`EXTERNAL_ID` VARCHAR(50) COMMENT 'Identifier for external system',
	`OFFER_PROFILE` TEXT (64000) COMMENT 'XML for offer profiling',
	`CREATED_BY_ID` VARCHAR(100) COMMENT 'ID of creator',
	`CREATED_DATE` DATETIME COMMENT 'Datetime of creation',
	`UPDATED_BY_ID` VARCHAR(100) COMMENT 'ID of last modifier',
	`UPDATED_DATE` DATETIME COMMENT 'Datetime of last modification',
	`DELETED_BY_ID` VARCHAR(100) COMMENT 'ID of eraser (logical deletion)',
	`DELETED_DATE` DATETIME COMMENT 'Datetime of logical deletion',
	`CHG_STATUS_BY_ID` VARCHAR(100) COMMENT 'ID of last STATUS modifier',
	`CHG_STATUS_DATE` DATETIME COMMENT 'Datetime of last STATUS modification',
	PRIMARY KEY (`OFFER_ID`)
	) ENGINE = INNODB COMMENT 'Table for offer catalog';

ALTER TABLE `SDP_OFFER` ADD UNIQUE INDEX `UK-SDP_OFFER-OFFER_NAME` (`OFFER_NAME`);

ALTER TABLE `SDP_OFFER` ADD INDEX `IDX_OFFER_SERVICE_VARIANT_ID` (`SERVICE_VARIANT_ID`);

ALTER TABLE `SDP_OFFER` ADD UNIQUE INDEX `UK-SDP_OFFER-EXTERNAL_ID` (`EXTERNAL_ID`);

ALTER TABLE `SDP_OFFER` ADD CONSTRAINT `FK-SDP_OFFER-SERVICEVARIANTID` FOREIGN KEY (`SERVICE_VARIANT_ID`) REFERENCES `SDP_SERVICE_VARIANT` (`SERVICE_VARIANT_ID`);

/*--------------------------------------------------------
--  DDL for Table SDP_SOLUTION
--------------------------------------------------------*/
CREATE TABLE `SDP_SOLUTION` (
	`SOLUTION_ID` BIGINT NOT NULL AUTO_INCREMENT COMMENT 'Solution identifier',
	`SOLUTION_TYPE_ID` BIGINT NOT NULL COMMENT 'Solution typology identifier',
	`SOLUTION_NAME` VARCHAR(100) NOT NULL COMMENT 'Solution name',
	`SOLUTION_DESCRIPTION` VARCHAR(255) COMMENT 'Solution description',
	`STATUS_ID` BIGINT DEFAULT 2 NOT NULL COMMENT 'Status identifier',
	`SOLUTION_PROFILE` TEXT (64000) COMMENT 'XML for solution profiling',
	`EXTERNAL_ID` VARCHAR(50) COMMENT 'Identifier for external system',
	`START_DATE` DATETIME COMMENT 'Validity start date',
	`END_DATE` DATETIME COMMENT 'Validity end date',
	`CREATED_BY_ID` VARCHAR(100) COMMENT 'ID of creator',
	`CREATED_DATE` DATETIME COMMENT 'Datetime of creation',
	`UPDATED_BY_ID` VARCHAR(100) COMMENT 'ID of last modifier',
	`UPDATED_DATE` DATETIME COMMENT 'Datetime of last modification',
	`DELETED_BY_ID` VARCHAR(100) COMMENT 'ID of eraser (logical deletion)',
	`DELETED_DATE` DATETIME COMMENT 'Datetime of logical deletion',
	`CHG_STATUS_BY_ID` VARCHAR(100) COMMENT 'ID of last STATUS modifier',
	`CHG_STATUS_DATE` DATETIME COMMENT 'Datetime of last STATUS modification',
	PRIMARY KEY (`SOLUTION_ID`)
	) ENGINE = INNODB COMMENT 'Table for solution definition';

ALTER TABLE `SDP_SOLUTION` ADD UNIQUE INDEX `UK-SDP_SOLUTION-SOLUTION_NAME` (`SOLUTION_NAME`);

ALTER TABLE `SDP_SOLUTION` ADD INDEX `IDX_SOLUTION_SOLUTION_TYPE_ID` (`SOLUTION_TYPE_ID`);

ALTER TABLE `SDP_SOLUTION` ADD UNIQUE INDEX `UK-SDP_SOLUTION-EXTERNAL_ID` (`EXTERNAL_ID`);

ALTER TABLE `SDP_SOLUTION` ADD CONSTRAINT `FK-SDP_SOLUTION-SOLUTIONTYPEID` FOREIGN KEY (`SOLUTION_TYPE_ID`) REFERENCES `REF_SOLUTION_TYPE` (`SOLUTION_TYPE_ID`);

/*--------------------------------------------------------
--  DDL for Table SDP_SOLUTION_OFFER
--------------------------------------------------------*/
CREATE TABLE `SDP_SOLUTION_OFFER` (
	`SOLUTION_OFFER_ID` BIGINT NOT NULL AUTO_INCREMENT COMMENT 'Solution offer identifier',
	`PARENT_SOLUTION_OFFER_ID` BIGINT COMMENT 'Parent Solution offer identifier (filled for child solution offer)',
	`SOLUTION_ID` BIGINT COMMENT 'Solution identifier  (filled for parent solution offer)',
	`SOLUTION_OFFER_NAME` VARCHAR(100) NOT NULL COMMENT 'Solution offer name',
	`SOLUTION_OFFER_DESCRIPTION` VARCHAR(255) COMMENT 'Solution offer description',
	`STATUS_ID` BIGINT DEFAULT 2 NOT NULL COMMENT 'Status identifier',
	`SOLUTION_OFFER_PROFILE` TEXT (64000) COMMENT 'XML for solution offer profiling',
	`EXTERNAL_ID` VARCHAR(50) COMMENT 'Identifier for external system',
	`START_DATE` DATETIME COMMENT 'Validity start date',
	`END_DATE` DATETIME COMMENT 'Validity end date',
	`CREATED_BY_ID` VARCHAR(100) COMMENT 'ID of creator',
	`CREATED_DATE` DATETIME COMMENT 'Datetime of creation',
	`UPDATED_BY_ID` VARCHAR(100) COMMENT 'ID of last modifier',
	`UPDATED_DATE` DATETIME COMMENT 'Datetime of last modification',
	`DELETED_BY_ID` VARCHAR(100) COMMENT 'ID of eraser (logical deletion)',
	`DELETED_DATE` DATETIME COMMENT 'Datetime of logical deletion',
	`CHG_STATUS_BY_ID` VARCHAR(100) COMMENT 'ID of last STATUS modifier',
	`CHG_STATUS_DATE` DATETIME COMMENT 'Datetime of last STATUS modification',
	`IS_BASIC_PROFILE` BIT DEFAULT 0 NOT NULL COMMENT 'Used by AVS',
	PRIMARY KEY (`SOLUTION_OFFER_ID`)
	) ENGINE = INNODB COMMENT 'Table for solution offer definition';

ALTER TABLE `SDP_SOLUTION_OFFER` ADD UNIQUE INDEX `UK-SDP_SOLTN_OFFER-SOLNOFFNAME` (`SOLUTION_OFFER_NAME`);

ALTER TABLE `SDP_SOLUTION_OFFER` ADD INDEX `IDX_SOLUTION_OFFER_PARENT_SOLUTION_OFFER_ID` (`PARENT_SOLUTION_OFFER_ID`);

ALTER TABLE `SDP_SOLUTION_OFFER` ADD UNIQUE INDEX `UK-SDP_SOLTN_OFFER-EXTERNAL_ID` (`EXTERNAL_ID`);

ALTER TABLE `SDP_SOLUTION_OFFER` ADD INDEX `IDX_SOLUTION_OFFER_SOLUTION_ID` (`SOLUTION_ID`);

ALTER TABLE `SDP_SOLUTION_OFFER` ADD CONSTRAINT `FX_SDP_SOL_OFFER_TO_SOLUTION` FOREIGN KEY (`SOLUTION_ID`) REFERENCES `SDP_SOLUTION` (`SOLUTION_ID`);

ALTER TABLE `SDP_SOLUTION_OFFER` ADD CONSTRAINT `FK-SDP_SOL_OFFER-PARENT_SOLUTION_OFFER_ID` FOREIGN KEY (`PARENT_SOLUTION_OFFER_ID`) REFERENCES `SDP_SOLUTION_OFFER` (`SOLUTION_OFFER_ID`);

/*--------------------------------------------------------
--  DDL for Table SDP_PACKAGE_GROUP
--------------------------------------------------------*/
CREATE TABLE `SDP_PACKAGE_GROUP` (
	`GROUP_ID` BIGINT NOT NULL AUTO_INCREMENT COMMENT 'Group identifier for optional offers',
	`GROUP_NAME` VARCHAR(100) NOT NULL COMMENT 'Group name',
	`SOLUTION_OFFER_ID` BIGINT NOT NULL COMMENT 'Solution offer identifier',
	`CREATED_BY_ID` VARCHAR(100) COMMENT 'ID of creator',
	`CREATED_DATE` DATETIME COMMENT 'Datetime of creation',
	`UPDATED_BY_ID` VARCHAR(100) COMMENT 'ID of last modifier',
	`UPDATED_DATE` DATETIME COMMENT 'Datetime of last modification',
	PRIMARY KEY (`GROUP_ID`)
	) ENGINE = INNODB COMMENT 'Table for package group catalog (ref by SDP_PACKAGE)';

ALTER TABLE `SDP_PACKAGE_GROUP` ADD UNIQUE INDEX `UK-SDP_PACKAGE_GROUP-GRPSOLOFF` (
	`GROUP_NAME`,
	`SOLUTION_OFFER_ID`
	);

ALTER TABLE `SDP_PACKAGE_GROUP` ADD CONSTRAINT `FK-SDP_PACKAGE_GROUP-SOLOFFID` FOREIGN KEY (`SOLUTION_OFFER_ID`) REFERENCES `SDP_SOLUTION_OFFER` (`SOLUTION_OFFER_ID`);

/*--------------------------------------------------------
--  DDL for Table SDP_PACKAGE
--------------------------------------------------------*/
CREATE TABLE `SDP_PACKAGE` (
	`PACKAGE_ID` BIGINT NOT NULL AUTO_INCREMENT COMMENT 'Package identifier',
	`BASE_PACKAGE_ID` BIGINT COMMENT 'Base Package identifier (filled for child offer)',
	`SOLUTION_OFFER_ID` BIGINT NOT NULL COMMENT 'Solution offer identifier',
	`OFFER_ID` BIGINT NOT NULL COMMENT 'Offer identifier',
	`GROUP_ID` BIGINT COMMENT 'Group identifier for optional offers (offers with same GroupId are mutually exclusive)',
	`PACKAGE_PRICE_ID` BIGINT NOT NULL COMMENT 'Package price identifier (ref SDP_PACKAGE_PRICE)',
	`IS_MANDATORY` CHAR(1) DEFAULT '0' NOT NULL COMMENT 'Flag mandatory (Y/N)' CHECK (
		`IS_MANDATORY` IN (
			'0',
			'1'
			)
		),
	`STATUS_ID` BIGINT DEFAULT 2 NOT NULL COMMENT 'Status identifier',
	`PACKAGE_PROFILE` TEXT (64000) COMMENT 'XML for package profiling',
	`EXTERNAL_ID` VARCHAR(50) COMMENT 'Identifier for external system',
	`CREATED_BY_ID` VARCHAR(100) COMMENT 'ID of creator',
	`CREATED_DATE` DATETIME COMMENT 'Datetime of creation',
	`UPDATED_BY_ID` VARCHAR(100) COMMENT 'ID of last modifier',
	`UPDATED_DATE` DATETIME COMMENT 'Datetime of last modification',
	`DELETED_BY_ID` VARCHAR(100) COMMENT 'ID of eraser (logical deletion)',
	`DELETED_DATE` DATETIME COMMENT 'Datetime of logical deletion',
	`CHG_STATUS_BY_ID` VARCHAR(100) COMMENT 'ID of last STATUS modifier',
	`CHG_STATUS_DATE` DATETIME COMMENT 'Datetime of last STATUS modification',
	PRIMARY KEY (`PACKAGE_ID`)
	) ENGINE = INNODB COMMENT 'Table for package catalog (aggregation of solution-offer/offer)';

ALTER TABLE `SDP_PACKAGE` ADD UNIQUE INDEX `UK-SDP_PACKAGE-SOLOFFID_OFFID` (
	`SOLUTION_OFFER_ID`,
	`OFFER_ID`
	);

ALTER TABLE `SDP_PACKAGE` ADD INDEX `IDX_PACKAGE_OFFER_ID` (`OFFER_ID`);

ALTER TABLE `SDP_PACKAGE` ADD INDEX `IDX_PACKAGE_BASE_PACKAGE_ID` (`BASE_PACKAGE_ID`);

ALTER TABLE `SDP_PACKAGE` ADD INDEX `IDX_PACKAGE_GROUP_ID` (`GROUP_ID`);

ALTER TABLE `SDP_PACKAGE` ADD UNIQUE INDEX `UK-SDP_PACKAGE-EXTERNAL_ID` (`EXTERNAL_ID`);

ALTER TABLE `SDP_PACKAGE` ADD CONSTRAINT `FK-SDP_PACKAGE-SOLUTIONOFFERID` FOREIGN KEY (`SOLUTION_OFFER_ID`) REFERENCES `SDP_SOLUTION_OFFER` (`SOLUTION_OFFER_ID`);

ALTER TABLE `SDP_PACKAGE` ADD CONSTRAINT `FK-SDP_PACKAGE-OFFER_ID` FOREIGN KEY (`OFFER_ID`) REFERENCES `SDP_OFFER` (`OFFER_ID`);

ALTER TABLE `SDP_PACKAGE` ADD CONSTRAINT `FK-SDP_PACKAGE-PACKAGEPRICEID` FOREIGN KEY (`PACKAGE_PRICE_ID`) REFERENCES `SDP_PACKAGE_PRICE` (`PACKAGE_PRICE_ID`);

ALTER TABLE `SDP_PACKAGE` ADD CONSTRAINT `FK-SDP_PACKAGE-BASE_PACKAGE_ID` FOREIGN KEY (`BASE_PACKAGE_ID`) REFERENCES `SDP_PACKAGE` (`PACKAGE_ID`);

ALTER TABLE `SDP_PACKAGE` ADD CONSTRAINT `FK-SDP_PACKAGE-GROUP_ID` FOREIGN KEY (`GROUP_ID`) REFERENCES `SDP_PACKAGE_GROUP` (`GROUP_ID`);

/*--------------------------------------------------------
--  DDL for Table SDP_DISCOUNT
--------------------------------------------------------*/
CREATE TABLE `SDP_DISCOUNT` (
	`DISCOUNT_ID` BIGINT NOT NULL AUTO_INCREMENT COMMENT 'Discount identifier',
	`SOLUTION_OFFER_ID` BIGINT NOT NULL COMMENT 'Solution Offer identifier',
	`PACKAGE_ID` BIGINT NOT NULL COMMENT 'Package identifier',
	`DISCOUNT_ABS_RC` DECIMAL(10, 2) COMMENT 'Absolute RC discount value',
	`DISCOUNT_ABS_NRC` DECIMAL(10, 2) COMMENT 'Absolute NRC discount value',
	`DISCOUNT_PERC_RC` DECIMAL(10, 2) COMMENT 'Percentage RC discount value',
	`DISCOUNT_PERC_NRC` DECIMAL(10, 2) COMMENT 'Percentage NRC discount value',
	`CREATED_BY_ID` VARCHAR(100) COMMENT 'ID of creator',
	`CREATED_DATE` DATETIME COMMENT 'Datetime of creation',
	`UPDATED_BY_ID` VARCHAR(100) COMMENT 'ID of last modifier',
	`UPDATED_DATE` DATETIME COMMENT 'Datetime of last modification',
	PRIMARY KEY (`DISCOUNT_ID`)
	) ENGINE = INNODB COMMENT 'Table for discount definition';

ALTER TABLE `SDP_DISCOUNT` ADD UNIQUE INDEX `UK-SDP_DISCOUNT-SOLOFFID_PACKID` (
	`SOLUTION_OFFER_ID`,
	`PACKAGE_ID`
	);

ALTER TABLE `SDP_DISCOUNT` ADD INDEX `IDX_DISCOUNT_SOLUTION_OFFER_ID` (`SOLUTION_OFFER_ID`);

ALTER TABLE `SDP_DISCOUNT` ADD INDEX `IDX_DISCOUNT_PACKAGE_ID` (`PACKAGE_ID`);

ALTER TABLE `SDP_DISCOUNT` ADD CONSTRAINT `FK-SDP_DISCOUNT-SOLUTION_OFFER_ID` FOREIGN KEY (`SOLUTION_OFFER_ID`) REFERENCES `SDP_SOLUTION_OFFER` (`SOLUTION_OFFER_ID`);

ALTER TABLE `SDP_DISCOUNT` ADD CONSTRAINT `FK-SDP_DISCOUNT-PACKAGE_ID` FOREIGN KEY (`PACKAGE_ID`) REFERENCES `SDP_PACKAGE` (`PACKAGE_ID`);

/*--------------------------------------------------------
--  DDL for Table REF_PARTY_GROUP
--------------------------------------------------------*/
CREATE TABLE `REF_PARTY_GROUP` (
	`PARTY_GROUP_ID` BIGINT NOT NULL AUTO_INCREMENT COMMENT 'Party group identifier',
	`PARTY_GROUP_NAME` VARCHAR(100) NOT NULL COMMENT 'Party group name',
	`PARTY_GROUP_DESCRIPTION` VARCHAR(255) COMMENT 'Party group description',
	`CREATED_BY_ID` VARCHAR(100) COMMENT 'ID of creator',
	`CREATED_DATE` DATETIME COMMENT 'Datetime of creation',
	`UPDATED_BY_ID` VARCHAR(100) COMMENT 'ID of last modifier',
	`UPDATED_DATE` DATETIME COMMENT 'Datetime of last modification',
	PRIMARY KEY (`PARTY_GROUP_ID`)
	) ENGINE = INNODB COMMENT 'Ref table for party groups (Business, Microbusiness, Top, etc.)';

ALTER TABLE `REF_PARTY_GROUP` ADD UNIQUE INDEX `UK-REF_PARTY_GROUP-GROUPNAME` (`PARTY_GROUP_NAME`);

/*--------------------------------------------------------
--  DDL for Table SDP_ROLE
--------------------------------------------------------*/
CREATE TABLE `SDP_ROLE` (
	`ROLE_NAME` VARCHAR(100) NOT NULL COMMENT 'Role name',
	`ROLE_DESCRIPTION` VARCHAR(255) COMMENT 'Role description',
	`CREATED_BY_ID` VARCHAR(100) COMMENT 'ID of creator',
	`CREATED_DATE` DATE COMMENT 'Datetime of creation',
	`UPDATED_BY_ID` VARCHAR(100) COMMENT 'ID of last modifier',
	`UPDATED_DATE` DATE COMMENT 'Datetime of last modification'
	) ENGINE = INNODB COMMENT 'Table for role definition';

ALTER TABLE `SDP_ROLE` ADD PRIMARY KEY (`ROLE_NAME`);

/*--------------------------------------------------------
--  DDL for Table LNK_PARTY_PARTY_GROUP
--------------------------------------------------------*/
CREATE TABLE `LNK_PARTY_PARTY_GROUP` (
	`PARTY_ID` BIGINT NOT NULL COMMENT 'Party identifier',
	`PARTY_GROUP_ID` BIGINT NOT NULL COMMENT 'Party group identifier',
	CONSTRAINT `PK-LNK_PARTY_PARTY_GROUP` PRIMARY KEY (
		`PARTY_ID`,
		`PARTY_GROUP_ID`
		),
	CONSTRAINT `FK-LNK_PARTY_PARTY_GROUP-GROUPID` FOREIGN KEY (`PARTY_GROUP_ID`) REFERENCES `REF_PARTY_GROUP`(`PARTY_GROUP_ID`)
	) ENGINE = INNODB COMMENT = 'Table for mapping between party and party group';

ALTER TABLE `LNK_PARTY_PARTY_GROUP` ADD INDEX `IDX_LNK_PARTY_PARTY_GROUP_PARTY_ID` (`PARTY_ID`);

/*--------------------------------------------------------
--  DDL for Table SDP_SECRET_QUESTION
--------------------------------------------------------*/
CREATE TABLE `SDP_SECRET_QUESTION` (
	`SECRET_QUESTION_ID` BIGINT NOT NULL AUTO_INCREMENT COMMENT 'Secret question identifier',
	`SECRET_QUESTION_DESCRIPTION` VARCHAR(255) NOT NULL COMMENT 'Secret question text',
	`SECRET_ANSWER` VARCHAR(255) NOT NULL COMMENT 'Secret answer text',
	`USERNAME` VARCHAR(100) NOT NULL COMMENT 'Username',
	`CREATED_BY_ID` VARCHAR(100) COMMENT 'ID of creator',
	`CREATED_DATE` DATETIME COMMENT 'Datetime of creation',
	`UPDATED_BY_ID` VARCHAR(100) COMMENT 'ID of last modifier',
	`UPDATED_DATE` DATETIME COMMENT 'Datetime of last modification',
	CONSTRAINT `PK-SDP_SECRET_QUESTION` PRIMARY KEY (`SECRET_QUESTION_ID`)
	) ENGINE = INNODB COMMENT 'Table for secret questions (password manage)';

ALTER TABLE `SDP_SECRET_QUESTION` ADD INDEX `IDX_SECRET_QST_PARTY_USERNAME` (`USERNAME`);

/*--------------------------------------------------------
--  DDL for Table SDP_PARTY_SITE
--------------------------------------------------------*/
CREATE TABLE `SDP_PARTY_SITE` (
	`SITE_ID` BIGINT NOT NULL AUTO_INCREMENT COMMENT 'Site identifier',
	`PARTY_ID` BIGINT NOT NULL COMMENT 'Party identifier',
	`STATUS_ID` BIGINT DEFAULT 2 NOT NULL COMMENT 'Status identifier',
	`SITE_NAME` VARCHAR(200) NOT NULL COMMENT 'Site name',
	`SITE_DESCRIPTION` VARCHAR(200) COMMENT 'Site description',
	`STREET_ADDRESS` VARCHAR(140) COMMENT 'Site Street address',
	`CITY` VARCHAR(100) COMMENT 'Site City',
	`ZIP_CODE` VARCHAR(20) COMMENT 'Site Zip code',
	`PROVINCE` VARCHAR(50) COMMENT 'Site Province',
	`COUNTRY` VARCHAR(100) COMMENT 'Site Country',
	`EXTERNAL_ID` VARCHAR(50) COMMENT 'Identifier for external system',
	`SITE_PROFILE` TEXT (64000) COMMENT 'XML for site profiling',
	`CREATED_BY_ID` VARCHAR(100) COMMENT 'ID of creator',
	`CREATED_DATE` DATETIME COMMENT 'Datetime of creation',
	`UPDATED_BY_ID` VARCHAR(100) COMMENT 'ID of last modifier',
	`UPDATED_DATE` DATETIME COMMENT 'Datetime of last modification',
	`DELETED_BY_ID` VARCHAR(100) COMMENT 'ID of eraser (logical deletion)',
	`DELETED_DATE` DATETIME COMMENT 'Datetime of logical deletion',
	`CHG_STATUS_BY_ID` VARCHAR(100) COMMENT 'ID of last STATUS modifier',
	`CHG_STATUS_DATE` DATETIME COMMENT 'Datetime of last STATUS modification',
	PRIMARY KEY (`SITE_ID`)
	) ENGINE = INNODB COMMENT 'Table for party site configuration';

ALTER TABLE `SDP_PARTY_SITE` ADD UNIQUE INDEX `UK-SDP_PARTY_SITE-PARTYID_SITE` (
	`SITE_NAME`,
	`PARTY_ID`
	);

ALTER TABLE `SDP_PARTY_SITE` ADD INDEX `IDX_PARTY_SITE_PARTY_ID` (`PARTY_ID`);

ALTER TABLE `SDP_PARTY_SITE` ADD UNIQUE INDEX `UK-SDP_PARTY_SITE-EXTERNAL_ID` (`EXTERNAL_ID`);

/*--------------------------------------------------------
--  DDL for Table LNK_SOLUTION_PARTY_GROUP
--------------------------------------------------------*/
CREATE TABLE `LNK_SOLUTION_PARTY_GROUP` (
	`SOLUTION_ID` BIGINT NOT NULL COMMENT 'Solution identifier',
	`PARTY_GROUP_ID` BIGINT NOT NULL COMMENT 'Party group identifier',
	`CREATED_BY_ID` VARCHAR(100) COMMENT 'ID of creator',
	`CREATED_DATE` DATE COMMENT 'Datetime of creation',
	`UPDATED_BY_ID` VARCHAR(100) COMMENT 'ID of last modifier',
	`UPDATED_DATE` DATE COMMENT 'Datetime of last modification'
	) ENGINE = INNODB COMMENT 'Table for mapping between solution and party group';

ALTER TABLE `LNK_SOLUTION_PARTY_GROUP` ADD CONSTRAINT `PK-LNK_SOL_PARTY_GROUP` PRIMARY KEY (
	`SOLUTION_ID`,
	`PARTY_GROUP_ID`
	);

ALTER TABLE `LNK_SOLUTION_PARTY_GROUP` ADD INDEX `IDX_LNK_SOL_PAR_PARTY_GROUP_ID` (`PARTY_GROUP_ID`);

ALTER TABLE `LNK_SOLUTION_PARTY_GROUP` ADD CONSTRAINT `FK-LNK_SOL_PARTY_GROUP-SOLTNID` FOREIGN KEY (`SOLUTION_ID`) REFERENCES `SDP_SOLUTION` (`SOLUTION_ID`);

ALTER TABLE `LNK_SOLUTION_PARTY_GROUP` ADD CONSTRAINT `FK-LNK_SOL_PARTY_GROUP-GROUPID` FOREIGN KEY (`PARTY_GROUP_ID`) REFERENCES `REF_PARTY_GROUP` (`PARTY_GROUP_ID`);

/*--------------------------------------------------------
--  DDL for Table LNK_SOLUTION_OFFER_PARTY_GROUP
-- a special gift for AVS
--------------------------------------------------------*/
CREATE TABLE `LNK_SOLUTION_OFFER_PARTY_GROUP` (
	`SOLUTION_OFFER_ID` BIGINT NOT NULL COMMENT 'Solution identifier',
	`PARTY_GROUP_ID` BIGINT NOT NULL COMMENT 'Party group identifier',
	`CREATED_BY_ID` VARCHAR(100) COMMENT 'ID of creator',
	`CREATED_DATE` DATE COMMENT 'Datetime of creation',
	`UPDATED_BY_ID` VARCHAR(100) COMMENT 'ID of last modifier',
	`UPDATED_DATE` DATE COMMENT 'Datetime of last modification'
	) ENGINE = INNODB COMMENT 'Table for mapping between solution and party group';

ALTER TABLE `LNK_SOLUTION_OFFER_PARTY_GROUP` ADD CONSTRAINT `PK-LNK_SOL_OFFER_PARTY_GROUP` PRIMARY KEY (
	`SOLUTION_OFFER_ID`,
	`PARTY_GROUP_ID`
	);

ALTER TABLE `LNK_SOLUTION_OFFER_PARTY_GROUP` ADD INDEX `IDX_LNK_SOL_OFFER_PAR_PARTY_GROUP_ID` (`PARTY_GROUP_ID`);

ALTER TABLE `LNK_SOLUTION_OFFER_PARTY_GROUP` ADD CONSTRAINT `FK-LNK_SOL_OFFER_PARTY_GROUP-SOLOFFID` FOREIGN KEY (`SOLUTION_OFFER_ID`) REFERENCES `SDP_SOLUTION_OFFER` (`SOLUTION_OFFER_ID`);

ALTER TABLE `LNK_SOLUTION_OFFER_PARTY_GROUP` ADD CONSTRAINT `FK-LNK_SOL_OFFER_PARTY_GROUP-GROUPID` FOREIGN KEY (`PARTY_GROUP_ID`) REFERENCES `REF_PARTY_GROUP` (`PARTY_GROUP_ID`);

/*--------------------------------------------------------
--  DDL for Table REF_TOKEN_PROVIDER
--------------------------------------------------------*/
CREATE TABLE REF_TOKEN_PROVIDER (
	TOKEN_PROVIDER VARCHAR(100) NOT NULL COMMENT 'Token provider identifier',
	TOKEN_VALIDITY_SECOND BIGINT NOT NULL COMMENT 'Token validity in seconds',
	CREATED_BY_ID VARCHAR(100) COMMENT 'ID of creator',
	CREATED_DATE DATETIME COMMENT 'Datetime of creation',
	UPDATED_BY_ID VARCHAR(100) COMMENT 'ID of last modifier',
	UPDATED_DATE DATETIME COMMENT 'Datetime of last modification'
	) ENGINE = INNODB COMMENT 'Ref table for token provider configuration';

ALTER TABLE `REF_TOKEN_PROVIDER` ADD PRIMARY KEY (TOKEN_PROVIDER);

/*--------------------------------------------------------
--  DDL for Table SDP_TOKEN
--------------------------------------------------------*/
CREATE TABLE SDP_TOKEN (
	TOKEN_ID VARCHAR(256) NOT NULL COMMENT 'Token identifier',
	TOKEN_PROVIDER VARCHAR(100) NOT NULL COMMENT 'Token provider identifier (ref REF_TOKEN_PROVIDER)',
	USER_IDENTIFIER VARCHAR(100) NOT NULL COMMENT 'Username referred to the token',
	TOKEN_TIMESTAMP BIGINT NOT NULL COMMENT 'Token date start validity in seconds',
	CREATED_BY_ID VARCHAR(100) COMMENT 'ID of creator',
	CREATED_DATE DATETIME COMMENT 'Datetime of creation',
	UPDATED_BY_ID VARCHAR(100) COMMENT 'ID of last modifier',
	UPDATED_DATE DATETIME COMMENT 'Datetime of last modification'
	) ENGINE = INNODB COMMENT 'Table for token information';

ALTER TABLE `SDP_TOKEN` ADD PRIMARY KEY (
	TOKEN_ID,
	TOKEN_PROVIDER
	);

ALTER TABLE `SDP_TOKEN` ADD CONSTRAINT `FK-SDP_TOKEN-TOKEN_PROVIDER` FOREIGN KEY (`TOKEN_PROVIDER`) REFERENCES `REF_TOKEN_PROVIDER` (`TOKEN_PROVIDER`);

/*--------------------------------------------------------
--  DDL for Table SDP_VOUCHER
--------------------------------------------------------*/
CREATE TABLE `SDP_VOUCHER` (
	`VOUCHER_ID` BIGINT NOT NULL AUTO_INCREMENT COMMENT 'Voucher identifier',
	`VOUCHER_CODE` VARCHAR(16) NOT NULL COMMENT 'Code of voucher',
	`VOUCHER_TYPE` VARCHAR(3) NOT NULL COMMENT 'Identifier of promotion',
	`VALIDITY_PERIOD` BIGINT DEFAULT NULL COMMENT 'Validity of promotion in days',
	`SOLUTION_OFFER_ID` BIGINT DEFAULT NULL COMMENT 'Solution Offer identifier',
	`PARTY_ID` BIGINT DEFAULT NULL COMMENT 'Identifier if Party (voucher is used)',
	`CREATED_BY_ID` VARCHAR(100) DEFAULT NULL COMMENT 'ID of creator',
	`CREATED_DATE` DATETIME DEFAULT NULL COMMENT 'Datetime of creation',
	`UPDATED_BY_ID` VARCHAR(100) DEFAULT NULL COMMENT 'ID of last modifier',
	`UPDATED_DATE` DATETIME DEFAULT NULL COMMENT 'Datetime of last modification',
	PRIMARY KEY (`VOUCHER_ID`),
	UNIQUE KEY `UK-SDP_VOUCHER-VOUCHER_CODE`(`VOUCHER_CODE`),
	KEY `FK-SDP_VOUCHER-PARTY_ID`(`PARTY_ID`),
	KEY `FK-SDP_VOUCHER-SOLOFFER_ID`(`SOLUTION_OFFER_ID`),
	CONSTRAINT `FK-SDP_VOUCHER-SOLOFFER_ID` FOREIGN KEY (`SOLUTION_OFFER_ID`) REFERENCES `SDP_SOLUTION_OFFER`(`SOLUTION_OFFER_ID`)
	) ENGINE = InnoDB COMMENT = 'Table for console voucher information';

/*--------------------------------------------------------
--  DDL for Table REF_DEVICE_UUID_TYPE
--------------------------------------------------------*/
CREATE TABLE REF_DEVICE_UUID_TYPE (
	DEVICE_UUID_TYPE_ID BIGINT NOT NULL AUTO_INCREMENT COMMENT 'Device UUID Type identifier',
	DEVICE_UUID_TYPE_NAME VARCHAR(100) NOT NULL COMMENT 'Device UUID Type name',
	DEVICE_UUID_TYPE_DESCRIPTION VARCHAR(255) COMMENT 'Device UUID Type description',
	DEVICE_UUID_TYPE_PATTERN VARCHAR(100) NOT NULL DEFAULT '.*' COMMENT 'regular expression of device uuid format',
	CONSTRAINT `PK-REF_DEVICE_UUID_TYPE` PRIMARY KEY (`DEVICE_UUID_TYPE_ID`),
	UNIQUE KEY `UK-REF_DEVICE_UUID_TYPE-UUID_TYPE_NAME`(`DEVICE_UUID_TYPE_NAME`)
	) ENGINE = INNODB COMMENT 'Ref table for Device UUID Type configuration';

/*--------------------------------------------------------
--  DDL for Table REF_DEVICE_CHANNEL
--------------------------------------------------------*/
CREATE TABLE `REF_DEVICE_CHANNEL` (
	`DEVICE_CHANNEL_ID` BIGINT NOT NULL AUTO_INCREMENT COMMENT 'Device Channel identifier',
	`DEVICE_CHANNEL_NAME` VARCHAR(100) NOT NULL COMMENT 'Device Channel name',
	`IS_PORTABLE` BIT DEFAULT 0 NOT NULL COMMENT 'Marked if Channel is portable',
	`IS_BL` BIT DEFAULT 0 NOT NULL COMMENT 'Marked if Channel is in blacklist',
	`IS_WL` BIT DEFAULT 0 NOT NULL COMMENT 'Marked if Channel is in whitelist',
	`BL_REASON` VARCHAR(1024) DEFAULT NULL COMMENT 'reason for blacklist',
	`CREATED_BY_ID` VARCHAR(100) COMMENT 'ID of creator',
	`CREATED_DATE` DATETIME COMMENT 'Datetime of creation',
	`UPDATED_BY_ID` VARCHAR(100) COMMENT 'ID of last modifier',
	`UPDATED_DATE` DATETIME COMMENT 'Datetime of last modification',
	CONSTRAINT `PK-REF_DEVICE_CHANNEL` PRIMARY KEY (`DEVICE_CHANNEL_ID`),
	UNIQUE KEY `UK-REF_DEVICE_CHANNEL-CHANNEL_NAME`(`DEVICE_CHANNEL_NAME`)
	) ENGINE = INNODB COMMENT 'Ref table for Device Channel configuration';

/*--------------------------------------------------------
--  DDL for Table REF_DEVICE_BRAND
--------------------------------------------------------*/
CREATE TABLE `REF_DEVICE_BRAND` (
	`DEVICE_BRAND_ID` BIGINT NOT NULL AUTO_INCREMENT COMMENT 'Device Brand identifier',
	`DEVICE_BRAND_NAME` VARCHAR(100) NOT NULL COMMENT 'Device Brand name',
	`IS_BL` BIT DEFAULT 0 NOT NULL COMMENT 'Marked if Brand is in blacklist',
	`IS_WL` BIT DEFAULT 0 NOT NULL COMMENT 'Marked if Brand is in whitelist',
	`BL_REASON` VARCHAR(1024) DEFAULT NULL COMMENT 'reason for blacklist',
	`CREATED_BY_ID` VARCHAR(100) COMMENT 'ID of creator',
	`CREATED_DATE` DATETIME COMMENT 'Datetime of creation',
	`UPDATED_BY_ID` VARCHAR(100) COMMENT 'ID of last modifier',
	`UPDATED_DATE` DATETIME COMMENT 'Datetime of last modification',
	CONSTRAINT `PK-REF_DEVICE_BRAND` PRIMARY KEY (`DEVICE_BRAND_ID`),
	UNIQUE KEY `UK-REF_DEVICE_BRAND-BRAND_NAME`(`DEVICE_BRAND_NAME`)
	) ENGINE = INNODB COMMENT 'Ref table for Device Brand configuration';

/*--------------------------------------------------------
--  DDL for Table REF_DEVICE_MODEL
--------------------------------------------------------*/
CREATE TABLE `REF_DEVICE_MODEL` (
	`DEVICE_MODEL_ID` BIGINT NOT NULL AUTO_INCREMENT COMMENT 'Device Model identifier',
	`DEVICE_MODEL_NAME` VARCHAR(100) NOT NULL COMMENT 'Device Model name',
	`DEVICE_BRAND_ID` BIGINT NOT NULL COMMENT 'Device Model identifier',
	`IS_BL` BIT DEFAULT 0 NOT NULL COMMENT 'Marked if Model is in blacklist',
	`IS_WL` BIT DEFAULT 0 NOT NULL COMMENT 'Marked if Model is in whitelist',
	`BL_REASON` VARCHAR(1024) DEFAULT NULL COMMENT 'reason for blacklist',
	`CREATED_BY_ID` VARCHAR(100) COMMENT 'ID of creator',
	`CREATED_DATE` DATETIME COMMENT 'Datetime of creation',
	`UPDATED_BY_ID` VARCHAR(100) COMMENT 'ID of last modifier',
	`UPDATED_DATE` DATETIME COMMENT 'Datetime of last modification',
	CONSTRAINT `PK-REF_DEVICE_MODEL` PRIMARY KEY (`DEVICE_MODEL_ID`),
	UNIQUE KEY `UK-REF_DEVICE_MODEL-MODEL_NAME`(`DEVICE_MODEL_NAME`),
	CONSTRAINT `FK-REF_DEVICE_MODEL-BRAND_ID` FOREIGN KEY (`DEVICE_BRAND_ID`) REFERENCES `REF_DEVICE_BRAND`(`DEVICE_BRAND_ID`)
	) ENGINE = INNODB COMMENT 'Ref table for Device Model configuration';

/*--------------------------------------------------------
--  DDL for Table SDP_DEVICE_POLICY
--------------------------------------------------------*/
CREATE TABLE `SDP_DEVICE_POLICY` (
	`POLICY_ID` BIGINT NOT NULL AUTO_INCREMENT COMMENT 'Policy identifier',
	`POLICY_NAME` VARCHAR(100) NOT NULL COMMENT 'Policy name',
	`NUMBER_OF_ASSOCIATIONS` BIGINT NOT NULL COMMENT 'Maximum number of device associations',
	`SAFETY_PERIOD_DURATION` BIGINT DEFAULT NULL COMMENT 'Safety period duration in days',
	`IS_DEFAULT` BIT DEFAULT NULL COMMENT 'Marked if Policy is the default one for parties',
	`CREATED_BY_ID` VARCHAR(100) COMMENT 'ID of creator',
	`CREATED_DATE` DATETIME COMMENT 'Datetime of creation',
	`UPDATED_BY_ID` VARCHAR(100) COMMENT 'ID of last modifier',
	`UPDATED_DATE` DATETIME COMMENT 'Datetime of last modification',
	CONSTRAINT `PK-SDP_DEVICE_POLICY` PRIMARY KEY (`POLICY_ID`),
	UNIQUE KEY `UK-SDP_DEVICE_POLICY-POLICY_NAME`(`POLICY_NAME`),
	CONSTRAINT `UK-SDP_DEVICE_POLICY-IS_DEFAULT` UNIQUE (IS_DEFAULT)
	) ENGINE = INNODB COMMENT 'Table for Policy configuration';

/*--------------------------------------------------------
--  DDL for Table SDP_DEVICE_POLICY_CONFIG
--------------------------------------------------------*/
CREATE TABLE `SDP_DEVICE_POLICY_CONFIG` (
	`POLICY_ID` BIGINT NOT NULL COMMENT 'Identifier of Policy',
	`DEVICE_CHANNEL_ID` BIGINT NOT NULL COMMENT 'Channel identifier',
	`MAXIMUM_ALLOWED_DEVICES` BIGINT NOT NULL COMMENT 'Maximum number of registered devices of same channel',
	CONSTRAINT `PK-SDP_DEVICE_POLICY_CONFIG` PRIMARY KEY (
		`POLICY_ID`,
		`DEVICE_CHANNEL_ID`
		),
	CONSTRAINT `FK-SDP_DEVICE_POLICY_CONFIG-POLICY_ID` FOREIGN KEY (`POLICY_ID`) REFERENCES `SDP_DEVICE_POLICY`(`POLICY_ID`),
	CONSTRAINT `FK-SDP_DEVICE_POLICY_CONFIG-CHANNEL_ID` FOREIGN KEY (`DEVICE_CHANNEL_ID`) REFERENCES `REF_DEVICE_CHANNEL`(`DEVICE_CHANNEL_ID`)
	) ENGINE = INNODB COMMENT 'Table for Policy details configuration about device number';

/*--------------------------------------------------------
--  DDL for Table SDP_PARTY_DEVICE_EXT
--------------------------------------------------------*/
CREATE TABLE `SDP_PARTY_DEVICE_EXT` (
	`PARTY_ID` BIGINT NOT NULL COMMENT 'Identifier of Party',
	`POLICY_ID` BIGINT NOT NULL COMMENT 'Policy identifier',
	`REGISTRATIONS_DONE` BIGINT NOT NULL COMMENT 'Registrations done',
	`SAFETY_PERIOD_EXPIRATION` DATETIME DEFAULT NULL COMMENT 'Safety Period expiration date',
	`IS_BL` BIT DEFAULT 0 NOT NULL COMMENT 'Marked if Party is in blacklist',
	`IS_WL` BIT DEFAULT 0 NOT NULL COMMENT 'Marked if Party is in whitelist',
	`BL_REASON` VARCHAR(1024) DEFAULT NULL COMMENT 'reason for blacklist',
	`CREATED_BY_ID` VARCHAR(100) COMMENT 'ID of creator',
	`CREATED_DATE` DATETIME COMMENT 'Datetime of creation',
	`UPDATED_BY_ID` VARCHAR(100) COMMENT 'ID of last modifier',
	`UPDATED_DATE` DATETIME COMMENT 'Datetime of last modification',
	CONSTRAINT `PK-SDP_PARTY_DEVICE_EXT` PRIMARY KEY (`PARTY_ID`),
	CONSTRAINT `FK-SDP_PARTY_DEVICE_EXT-POLICY_ID` FOREIGN KEY (`POLICY_ID`) REFERENCES `SDP_DEVICE_POLICY`(`POLICY_ID`)
	) ENGINE = INNODB COMMENT 'SDP_Party extension for device configuration management';

/*--------------------------------------------------------
--  DDL for Table SDP_DEVICE_COUNTER_CONFIG
--------------------------------------------------------*/
CREATE TABLE `SDP_DEVICE_COUNTER_CONFIG` (
	`PARTY_ID` BIGINT NOT NULL COMMENT 'Identifier of Party',
	`DEVICE_CHANNEL_ID` BIGINT NOT NULL COMMENT 'Channel identifier',
	`REGISTERED_DEVICES` BIGINT NOT NULL COMMENT 'number of registered devices of same channel',
	CONSTRAINT `PK-SDP_DEVICE_COUNTER_CONFIG` PRIMARY KEY (
		`PARTY_ID`,
		`DEVICE_CHANNEL_ID`
		),
	CONSTRAINT `FK-SDP_DEVICE_COUNTER_CONFIG-PARTY_ID` FOREIGN KEY (`PARTY_ID`) REFERENCES `SDP_PARTY_DEVICE_EXT`(`PARTY_ID`),
	CONSTRAINT `FK-SDP_DEVICE_COUNTER_CONFIG-CHANNEL_ID` FOREIGN KEY (`DEVICE_CHANNEL_ID`) REFERENCES `REF_DEVICE_CHANNEL`(`DEVICE_CHANNEL_ID`)
	) ENGINE = INNODB COMMENT 'Table for records of Party operations about policy rules';

/*--------------------------------------------------------
--  DDL for Table SDP_DEVICE
--------------------------------------------------------*/
CREATE TABLE `SDP_DEVICE` (
	`DEVICE_UUID` VARCHAR(128) NOT NULL COMMENT 'Device identifier',
	`DEVICE_UUID_TYPE_ID` BIGINT NOT NULL COMMENT 'Identifier of UUID type',
	`DEVICE_CHANNEL_ID` BIGINT NOT NULL COMMENT 'Identifier of Channel',
	`PARTY_ID` BIGINT NOT NULL COMMENT 'Identifier of Party',
	`DEVICE_BRAND_ID` BIGINT DEFAULT NULL COMMENT 'Identifier of Brand',
	`DEVICE_MODEL_ID` BIGINT DEFAULT NULL COMMENT 'Identifier of Model',
	`ALIAS` VARCHAR(200) DEFAULT NULL COMMENT 'Mnemonic alias of device',
	`STATUS_ID` BIGINT DEFAULT 2 NOT NULL COMMENT 'Status identifier',
	`LAST_FRUITION_DATE` DATETIME DEFAULT NULL COMMENT 'Last content fruition date for device',
	`IS_PAIRED` BIT DEFAULT 0 NOT NULL COMMENT 'Marked if device is paired',
	`IS_BL` BIT DEFAULT 0 NOT NULL COMMENT 'Marked if device is in blacklist',
	`IS_WL` BIT DEFAULT 0 NOT NULL COMMENT 'Marked if device is in whitelist',
	`BL_REASON` VARCHAR(1024) DEFAULT NULL COMMENT 'reason for blacklist',
	`CREATED_BY_ID` VARCHAR(100) COMMENT 'ID of creator',
	`CREATED_DATE` DATETIME COMMENT 'Datetime of creation',
	`UPDATED_BY_ID` VARCHAR(100) COMMENT 'ID of last modifier',
	`UPDATED_DATE` DATETIME COMMENT 'Datetime of last modification',
	`DELETED_BY_ID` VARCHAR(100) COMMENT 'ID of eraser (logical deletion)',
	`DELETED_DATE` DATETIME COMMENT 'Datetime of logical deletion',
	`CHG_STATUS_BY_ID` VARCHAR(100) COMMENT 'ID of last STATUS modifier',
	`CHG_STATUS_DATE` DATETIME COMMENT 'Datetime of last STATUS modification',
	CONSTRAINT `PK-SDP_DEVICE` PRIMARY KEY (`DEVICE_UUID`),
	CONSTRAINT `FK-SDP_DEVICE-PARTY_ID` FOREIGN KEY (`PARTY_ID`) REFERENCES `SDP_PARTY_DEVICE_EXT`(`PARTY_ID`),
	CONSTRAINT `FK-SDP_DEVICE-UUID_TYPE_ID` FOREIGN KEY (`DEVICE_UUID_TYPE_ID`) REFERENCES `REF_DEVICE_UUID_TYPE`(`DEVICE_UUID_TYPE_ID`),
	CONSTRAINT `FK-SDP_DEVICE-CHANNEL_ID` FOREIGN KEY (`DEVICE_CHANNEL_ID`) REFERENCES `REF_DEVICE_CHANNEL`(`DEVICE_CHANNEL_ID`),
	CONSTRAINT `FK-SDP_DEVICE-DEVICE_BRAND_ID` FOREIGN KEY (`DEVICE_BRAND_ID`) REFERENCES `REF_DEVICE_BRAND`(`DEVICE_BRAND_ID`),
	CONSTRAINT `FK-SDP_DEVICE-DEVICE_MODEL_ID` FOREIGN KEY (`DEVICE_MODEL_ID`) REFERENCES `REF_DEVICE_MODEL`(`DEVICE_MODEL_ID`)
	) ENGINE = InnoDB COMMENT = 'Table for devices';

/*--------------------------------------------------------
--  DDL for Table REF_ITEM_TYPE
--------------------------------------------------------*/
CREATE TABLE `REF_ITEM_TYPE` (
	`ITEM_TYPE_ID` BIGINT NOT NULL AUTO_INCREMENT COMMENT 'Shopping cart item type identifier',
	`ITEM_TYPE_NAME` VARCHAR(100) NOT NULL COMMENT 'Shopping cart item type name',
	CONSTRAINT `PK-REF_ITEM_TYPE` PRIMARY KEY (`ITEM_TYPE_ID`),
	UNIQUE KEY `UK-REF_ITEM_TYPE-TYPE_NAME`(`ITEM_TYPE_NAME`)
	) ENGINE = INNODB COMMENT 'Ref table for Shopping cart item types';

/*--------------------------------------------------------
--  DDL for Table SDP_SHOPPING_CART
--------------------------------------------------------*/
CREATE TABLE `SDP_SHOPPING_CART` (
	`SHOPPING_CART_ID` BIGINT NOT NULL AUTO_INCREMENT COMMENT 'Shopping cart identifier',
	`PARTY_ID` BIGINT NOT NULL COMMENT 'Party identifier of shopping cart owner',
	`STATUS_ID` BIGINT DEFAULT 2 NOT NULL COMMENT 'Status identifier',
	`CREATED_BY_ID` VARCHAR(100) COMMENT 'ID of creator',
	`CREATED_DATE` DATETIME COMMENT 'Datetime of creation',
	`UPDATED_BY_ID` VARCHAR(100) COMMENT 'ID of last modifier',
	`UPDATED_DATE` DATETIME COMMENT 'Datetime of last modification',
	`CHG_STATUS_BY_ID` VARCHAR(100) COMMENT 'ID of last STATUS modifier',
	`CHG_STATUS_DATE` DATETIME COMMENT 'Datetime of last STATUS modification',
	CONSTRAINT `PK-SDP_SHOPPING_CART` PRIMARY KEY (`SHOPPING_CART_ID`),
	KEY `FK-SDP_SHOPPING_CART-PARTY_ID`(`PARTY_ID`)
	) ENGINE = INNODB COMMENT 'Table for Shopping cart';

/*--------------------------------------------------------
--  DDL for Table SDP_SHOPPING_CART_ITEM
--------------------------------------------------------*/
CREATE TABLE `SDP_SHOPPING_CART_ITEM` (
	`ITEM_ID` BIGINT NOT NULL COMMENT 'Shopping cart item identifier',
	`SHOPPING_CART_ID` BIGINT NOT NULL COMMENT 'Shopping cart identifier',
	`ITEM_DESCRIPTION` VARCHAR(1024) DEFAULT NULL COMMENT 'Item description',
	`ITEM_TYPE_ID` BIGINT NOT NULL COMMENT 'Item type identifier',
	`QUANTITY` BIGINT DEFAULT 1 NOT NULL COMMENT 'Quantity per item',
	`ITEM_PRICE` DECIMAL(10, 2) NOT NULL COMMENT 'Price of a single item',
	`ITEM_SUBTOTAL` DECIMAL(10, 2) NOT NULL COMMENT 'Item subtotal price',
	`CREATED_BY_ID` VARCHAR(100) COMMENT 'ID of creator',
	`CREATED_DATE` DATETIME COMMENT 'Datetime of creation',
	`UPDATED_BY_ID` VARCHAR(100) COMMENT 'ID of last modifier',
	`UPDATED_DATE` DATETIME COMMENT 'Datetime of last modification',
	CONSTRAINT `PK-SDP_SHOPPING_CART_ITEM` PRIMARY KEY (`ITEM_ID`, `SHOPPING_CART_ID`, `ITEM_TYPE_ID`),
	CONSTRAINT `FK-SDP_SHOPPING_CART_ITEM-ITEM_TYPE_ID` FOREIGN KEY (`ITEM_TYPE_ID`) REFERENCES `REF_ITEM_TYPE`(`ITEM_TYPE_ID`),
	CONSTRAINT `FK-SDP_SHOPPING_CART_ITEM-SHOPPING_CART_ID` FOREIGN KEY (`SHOPPING_CART_ID`) REFERENCES `SDP_SHOPPING_CART`(`SHOPPING_CART_ID`)
	) ENGINE = INNODB COMMENT 'Table for Shopping cart items';

/*--------------------------------------------------------
--  POPULATE TABLES
--------------------------------------------------------*/
INSERT INTO REF_PARTY_GROUP (PARTY_GROUP_NAME, PARTY_GROUP_DESCRIPTION, CREATED_BY_ID, CREATED_DATE)
VALUES ('ALL', 'Every subscriber', 'Configurator', curdate());

INSERT INTO REF_SERVICE_TYPE (SERVICE_TYPE_ID, SERVICE_TYPE_NAME, SERVICE_TYPE_DESCRIPTION, CREATED_BY_ID, CREATED_DATE)
VALUES (1, 'VAS', 'Value Added Services', 'Configurator', curdate());
INSERT INTO REF_SERVICE_TYPE (SERVICE_TYPE_ID, SERVICE_TYPE_NAME, SERVICE_TYPE_DESCRIPTION, CREATED_BY_ID, CREATED_DATE)
VALUES (2, 'CORE SERVICES', 'Core Services', 'Configurator', curdate());

INSERT INTO REF_SOLUTION_TYPE (SOLUTION_TYPE_ID, SOLUTION_TYPE_NAME, SOLUTION_TYPE_DESCRIPTION, CREATED_BY_ID, CREATED_DATE)
VALUES (1, 'Default', 'Default Solution', 'Configurator', curdate());

INSERT INTO REF_FREQUENCY_TYPE (FREQUENCY_TYPE_NAME, FREQUENCY_TYPE_DESCRIPTION, FREQUENCY_IN_DAYS, CREATED_BY_ID, CREATED_DATE)
VALUES ('No frequency', 'Default value for zero price RC', 0, 'Configurator', curdate());

INSERT INTO REF_PRICE_CATALOG (PRICE, CREATED_BY_ID, CREATED_DATE)
VALUES (0, 'Configurator', curdate());

INSERT INTO REF_CURRENCY_TYPE (CURRENCY_TYPE_NAME, CREATED_BY_ID, CREATED_DATE)
VALUES ('AUD', 'Configurator', curdate());

INSERT INTO SDP_ROLE (ROLE_NAME, ROLE_DESCRIPTION, CREATED_BY_ID, CREATED_DATE)
VALUES ('Administrator', 'System Administrator', 'Configurator', curdate());
INSERT INTO SDP_ROLE (ROLE_NAME, ROLE_DESCRIPTION, CREATED_BY_ID, CREATED_DATE)
VALUES ('User', 'User simple', 'Configurator', curdate());

INSERT INTO REF_ENTITY_TYPE (ENTITY_ID, ENTITY_NAME, ENTITY_DESCRIPTION, CREATED_BY_ID, CREATED_DATE)
VALUES (0, 'Other', 'Other entities', 'Configurator', curdate());
INSERT INTO REF_ENTITY_TYPE (ENTITY_ID, ENTITY_NAME, ENTITY_DESCRIPTION, CREATED_BY_ID, CREATED_DATE)
VALUES (1, 'Subscription', 'Subscription/Subscription detail', 'Configurator', curdate());
INSERT INTO REF_ENTITY_TYPE (ENTITY_ID, ENTITY_NAME, ENTITY_DESCRIPTION, CREATED_BY_ID, CREATED_DATE)
VALUES (2, 'Shoppingcart', 'Shopping Cart', 'Configurator', curdate());

INSERT INTO SDP_STATUS_VARIATION (ENTITY_ID, PREVIOUS_STATUS_ID, NEXT_STATUS_ID, CREATED_BY_ID, CREATED_DATE)
VALUES (0, 2, 3, 'Configurator', curdate());
INSERT INTO SDP_STATUS_VARIATION (ENTITY_ID, PREVIOUS_STATUS_ID, NEXT_STATUS_ID, CREATED_BY_ID, CREATED_DATE)
VALUES (0, 2, 4, 'Configurator', curdate());
INSERT INTO SDP_STATUS_VARIATION (ENTITY_ID, PREVIOUS_STATUS_ID, NEXT_STATUS_ID, CREATED_BY_ID, CREATED_DATE)
VALUES (0, 3, 2, 'Configurator', curdate());
INSERT INTO SDP_STATUS_VARIATION (ENTITY_ID, PREVIOUS_STATUS_ID, NEXT_STATUS_ID, CREATED_BY_ID, CREATED_DATE)
VALUES (0, 3, 4, 'Configurator', curdate());
INSERT INTO SDP_STATUS_VARIATION (ENTITY_ID, PREVIOUS_STATUS_ID, NEXT_STATUS_ID, CREATED_BY_ID, CREATED_DATE)
VALUES (0, 4, 2, 'Configurator', curdate());
INSERT INTO SDP_STATUS_VARIATION (ENTITY_ID, PREVIOUS_STATUS_ID, NEXT_STATUS_ID, CREATED_BY_ID, CREATED_DATE)
VALUES (0, 4, 3, 'Configurator', curdate());
INSERT INTO SDP_STATUS_VARIATION (ENTITY_ID, PREVIOUS_STATUS_ID, NEXT_STATUS_ID, CREATED_BY_ID, CREATED_DATE)
VALUES (0, 4, 5, 'Configurator', curdate());

INSERT INTO SDP_STATUS_VARIATION (ENTITY_ID, PREVIOUS_STATUS_ID, NEXT_STATUS_ID, CREATED_BY_ID, CREATED_DATE)
VALUES (1, 1, 6, 'Configurator', curdate());
INSERT INTO SDP_STATUS_VARIATION (ENTITY_ID, PREVIOUS_STATUS_ID, NEXT_STATUS_ID, CREATED_BY_ID, CREATED_DATE)
VALUES (1, 1, 2, 'Configurator', curdate());
INSERT INTO SDP_STATUS_VARIATION (ENTITY_ID, PREVIOUS_STATUS_ID, NEXT_STATUS_ID, CREATED_BY_ID, CREATED_DATE)
VALUES (1, 6, 2, 'Configurator', curdate());
INSERT INTO SDP_STATUS_VARIATION (ENTITY_ID, PREVIOUS_STATUS_ID, NEXT_STATUS_ID, CREATED_BY_ID, CREATED_DATE)
VALUES (1, 2, 9, 'Configurator', curdate());
INSERT INTO SDP_STATUS_VARIATION (ENTITY_ID, PREVIOUS_STATUS_ID, NEXT_STATUS_ID, CREATED_BY_ID, CREATED_DATE)
VALUES (1, 2, 10, 'Configurator', curdate());
INSERT INTO SDP_STATUS_VARIATION (ENTITY_ID, PREVIOUS_STATUS_ID, NEXT_STATUS_ID, CREATED_BY_ID, CREATED_DATE)
VALUES (1, 2, 11, 'Configurator', curdate());
INSERT INTO SDP_STATUS_VARIATION (ENTITY_ID, PREVIOUS_STATUS_ID, NEXT_STATUS_ID, CREATED_BY_ID, CREATED_DATE)
VALUES (1, 9, 2, 'Configurator', curdate());
INSERT INTO SDP_STATUS_VARIATION (ENTITY_ID, PREVIOUS_STATUS_ID, NEXT_STATUS_ID, CREATED_BY_ID, CREATED_DATE)
VALUES (1, 9, 13, 'Configurator', curdate());
INSERT INTO SDP_STATUS_VARIATION (ENTITY_ID, PREVIOUS_STATUS_ID, NEXT_STATUS_ID, CREATED_BY_ID, CREATED_DATE)
VALUES (1, 13, 9, 'Configurator', curdate());
INSERT INTO SDP_STATUS_VARIATION (ENTITY_ID, PREVIOUS_STATUS_ID, NEXT_STATUS_ID, CREATED_BY_ID, CREATED_DATE)
VALUES (1, 10, 7, 'Configurator', curdate());
INSERT INTO SDP_STATUS_VARIATION (ENTITY_ID, PREVIOUS_STATUS_ID, NEXT_STATUS_ID, CREATED_BY_ID, CREATED_DATE)
VALUES (1, 10, 3, 'Configurator', curdate());
INSERT INTO SDP_STATUS_VARIATION (ENTITY_ID, PREVIOUS_STATUS_ID, NEXT_STATUS_ID, CREATED_BY_ID, CREATED_DATE)
VALUES (1, 7, 3, 'Configurator', curdate());
INSERT INTO SDP_STATUS_VARIATION (ENTITY_ID, PREVIOUS_STATUS_ID, NEXT_STATUS_ID, CREATED_BY_ID, CREATED_DATE)
VALUES (1, 3, 1, 'Configurator', curdate());
INSERT INTO SDP_STATUS_VARIATION (ENTITY_ID, PREVIOUS_STATUS_ID, NEXT_STATUS_ID, CREATED_BY_ID, CREATED_DATE)
VALUES (1, 3, 11, 'Configurator', curdate());
INSERT INTO SDP_STATUS_VARIATION (ENTITY_ID, PREVIOUS_STATUS_ID, NEXT_STATUS_ID, CREATED_BY_ID, CREATED_DATE)
VALUES (1, 11, 4, 'Configurator', curdate());
INSERT INTO SDP_STATUS_VARIATION (ENTITY_ID, PREVIOUS_STATUS_ID, NEXT_STATUS_ID, CREATED_BY_ID, CREATED_DATE)
VALUES (1, 11, 8, 'Configurator', curdate());
INSERT INTO SDP_STATUS_VARIATION (ENTITY_ID, PREVIOUS_STATUS_ID, NEXT_STATUS_ID, CREATED_BY_ID, CREATED_DATE)
VALUES (1, 8, 4, 'Configurator', curdate());
INSERT INTO SDP_STATUS_VARIATION (ENTITY_ID, PREVIOUS_STATUS_ID, NEXT_STATUS_ID, CREATED_BY_ID, CREATED_DATE)
VALUES (1, 4, 12, 'Configurator', curdate());
INSERT INTO SDP_STATUS_VARIATION (ENTITY_ID, PREVIOUS_STATUS_ID, NEXT_STATUS_ID, CREATED_BY_ID, CREATED_DATE)
VALUES (1, 4, 10, 'Configurator', curdate());
INSERT INTO SDP_STATUS_VARIATION (ENTITY_ID, PREVIOUS_STATUS_ID, NEXT_STATUS_ID, CREATED_BY_ID, CREATED_DATE)
VALUES (1, 4, 1, 'Configurator', curdate());
INSERT INTO SDP_STATUS_VARIATION (ENTITY_ID, PREVIOUS_STATUS_ID, NEXT_STATUS_ID, CREATED_BY_ID, CREATED_DATE)
VALUES (1, 12, 14, 'Configurator', curdate());
INSERT INTO SDP_STATUS_VARIATION (ENTITY_ID, PREVIOUS_STATUS_ID, NEXT_STATUS_ID, CREATED_BY_ID, CREATED_DATE)
VALUES (1, 12, 5, 'Configurator', curdate());
INSERT INTO SDP_STATUS_VARIATION (ENTITY_ID, PREVIOUS_STATUS_ID, NEXT_STATUS_ID, CREATED_BY_ID, CREATED_DATE)
VALUES (1, 14, 5, 'Configurator', curdate());
INSERT INTO SDP_STATUS_VARIATION (ENTITY_ID, PREVIOUS_STATUS_ID, NEXT_STATUS_ID, CREATED_BY_ID, CREATED_DATE)
VALUES (2, 15, 16, 'Configurator', curdate());

INSERT INTO `SDP_PLATFORM`
VALUES (1, 'AVSPlatform', 'AVSPlatform', 2, '', NULL, 'Stubber', curdate(), NULL, NULL, NULL, NULL, NULL, NULL);

INSERT INTO `SDP_SERVICE_TEMPLATE`
VALUES (1, 'AVSServiceTemplate', 'AVSServiceTemplate', 2, 1, 1, '', NULL, 'Stubber', curdate(), NULL, NULL, NULL, NULL, NULL, NULL);

INSERT INTO `SDP_SERVICE_VARIANT`
VALUES (1, 'AVSServiceVariant', 'AVSServiceVariant', 1, 2, NULL, '', 'Stubber', curdate(), NULL, NULL, NULL, NULL, NULL, NULL);

INSERT INTO `SDP_SOLUTION`
VALUES (1, 1, 'AVSSolution', 'AVSSolution', 2, NULL, NULL, '2012-04-26 00:00:00', NULL, 'Stubber', curdate(), NULL, NULL, NULL, NULL, NULL, NULL);

INSERT INTO REF_DEVICE_CHANNEL (DEVICE_CHANNEL_NAME, IS_PORTABLE, IS_WL, IS_BL, BL_REASON)
VALUES ('PCTV', b'0', b'0', b'0', NULL);
INSERT INTO REF_DEVICE_CHANNEL (DEVICE_CHANNEL_NAME, IS_PORTABLE, IS_WL, IS_BL, BL_REASON)
VALUES ('IPAD', b'0', b'0', b'0', NULL);
INSERT INTO REF_DEVICE_CHANNEL (DEVICE_CHANNEL_NAME, IS_PORTABLE, IS_WL, IS_BL, BL_REASON)
VALUES ('OTTSTB', b'0', b'0', b'0', NULL);
INSERT INTO REF_DEVICE_CHANNEL (DEVICE_CHANNEL_NAME, IS_PORTABLE, IS_WL, IS_BL, BL_REASON)
VALUES ('ANDROID', b'0', b'0', b'0', NULL);
INSERT INTO REF_DEVICE_CHANNEL (DEVICE_CHANNEL_NAME, IS_PORTABLE, IS_WL, IS_BL, BL_REASON)
VALUES ('CONNECTED', b'0', b'0', b'0', NULL);
INSERT INTO REF_DEVICE_CHANNEL (DEVICE_CHANNEL_NAME, IS_PORTABLE, IS_WL, IS_BL, BL_REASON)
VALUES ('XBOX', b'1', b'0', b'0', NULL);

INSERT INTO SDP_DEVICE_POLICY (POLICY_NAME, NUMBER_OF_ASSOCIATIONS, SAFETY_PERIOD_DURATION, IS_DEFAULT, CREATED_BY_ID, CREATED_DATE)
VALUES ('DefaultPolicy', 10, 365, b'1', 'Configurator', curdate());
INSERT INTO SDP_DEVICE_POLICY_CONFIG (DEVICE_CHANNEL_ID, MAXIMUM_ALLOWED_DEVICES, POLICY_ID)
VALUES ((SELECT DEVICE_CHANNEL_ID FROM REF_DEVICE_CHANNEL WHERE DEVICE_CHANNEL_NAME='PCTV'),10,(SELECT POLICY_ID from SDP_DEVICE_POLICY WHERE IS_DEFAULT='1'));
INSERT INTO SDP_DEVICE_POLICY_CONFIG (DEVICE_CHANNEL_ID, MAXIMUM_ALLOWED_DEVICES, POLICY_ID)
VALUES ((SELECT DEVICE_CHANNEL_ID FROM REF_DEVICE_CHANNEL WHERE DEVICE_CHANNEL_NAME='IPAD'),10,(SELECT POLICY_ID from SDP_DEVICE_POLICY WHERE IS_DEFAULT='1'));
INSERT INTO SDP_DEVICE_POLICY_CONFIG (DEVICE_CHANNEL_ID, MAXIMUM_ALLOWED_DEVICES, POLICY_ID)
VALUES ((SELECT DEVICE_CHANNEL_ID FROM REF_DEVICE_CHANNEL WHERE DEVICE_CHANNEL_NAME='OTTSTB'),10,(SELECT POLICY_ID from SDP_DEVICE_POLICY WHERE IS_DEFAULT='1'));
INSERT INTO SDP_DEVICE_POLICY_CONFIG (DEVICE_CHANNEL_ID, MAXIMUM_ALLOWED_DEVICES, POLICY_ID)
VALUES ((SELECT DEVICE_CHANNEL_ID FROM REF_DEVICE_CHANNEL WHERE DEVICE_CHANNEL_NAME='ANDROID'),10,(SELECT POLICY_ID from SDP_DEVICE_POLICY WHERE IS_DEFAULT='1'));
INSERT INTO SDP_DEVICE_POLICY_CONFIG (DEVICE_CHANNEL_ID, MAXIMUM_ALLOWED_DEVICES, POLICY_ID)
VALUES ((SELECT DEVICE_CHANNEL_ID FROM REF_DEVICE_CHANNEL WHERE DEVICE_CHANNEL_NAME='CONNECTED'),10,(SELECT POLICY_ID from SDP_DEVICE_POLICY WHERE IS_DEFAULT='1'));
INSERT INTO SDP_DEVICE_POLICY_CONFIG (DEVICE_CHANNEL_ID, MAXIMUM_ALLOWED_DEVICES, POLICY_ID)
VALUES ((SELECT DEVICE_CHANNEL_ID FROM REF_DEVICE_CHANNEL WHERE DEVICE_CHANNEL_NAME='XBOX'),10,(SELECT POLICY_ID from SDP_DEVICE_POLICY WHERE IS_DEFAULT='1'));


INSERT INTO REF_DEVICE_UUID_TYPE (DEVICE_UUID_TYPE_NAME, DEVICE_UUID_TYPE_DESCRIPTION,DEVICE_UUID_TYPE_PATTERN)
VALUES ('XBOX_XUID','XBOX_XUID','^[a-zA-Z0-9.-_]+@[a-zA-Z0-9.-]+\.[a-zA-Z]{2,4}$');
INSERT INTO REF_DEVICE_UUID_TYPE (DEVICE_UUID_TYPE_NAME, DEVICE_UUID_TYPE_DESCRIPTION,DEVICE_UUID_TYPE_PATTERN)
VALUES ('SMARTCARD','SMARTCARD','^[0-9]+$');
INSERT INTO REF_DEVICE_UUID_TYPE (DEVICE_UUID_TYPE_NAME, DEVICE_UUID_TYPE_DESCRIPTION,DEVICE_UUID_TYPE_PATTERN)
VALUES ('SERIALNUMBER','SERIALNUMBER','^[0-9a-fA-F]{8}-([0-9a-fA-F]{4}-){3}[0-9a-fA-F]{12}$');
INSERT INTO REF_DEVICE_UUID_TYPE (DEVICE_UUID_TYPE_NAME, DEVICE_UUID_TYPE_DESCRIPTION,DEVICE_UUID_TYPE_PATTERN)
VALUES ('MACADDRESS','MACADDRESS','^[0-9a-fA-F]{2}([:-][0-9a-fA-F]{2}){5}$');	

INSERT INTO REF_CSM_CONSTANTS (CONSTANT_KEY,CONSTANT_VALUE) values ('IS_AUTHENTICATION_ENABLED','FALSE');
INSERT INTO REF_CSM_CONSTANTS (CONSTANT_KEY,CONSTANT_VALUE) values ('IS_PAIRING_ENABLED','FALSE');

COMMIT;